<?php
define("TOKEN", "txe970731");
$wechatObj = new wechatCallbackapiTest();
if (!isset($_GET['echostr'])) {
    $wechatObj->responseMsg();
}else{
    $wechatObj->valid();
}

class wechatCallbackapiTest
{
	
    public function valid()
    {
        $echoStr = $_GET["echostr"];
        if($this->checkSignature()){
            echo $echoStr;
            exit;
        }
    }
	

    private function checkSignature()
    {
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];

        $token = TOKEN;
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );

        if( $tmpStr == $signature ){
            return true;
        }else{
            return false;
        }
    }

    public function responseMsg()
    {
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        if (!empty($postStr)){
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            $RX_TYPE = trim($postObj->MsgType);
            switch ($RX_TYPE)
            {
                case "event":					
					$resultStr = $this->receiveEvent($postObj);	
					break;					
                case "text":
					$step=$this->checkStep($postObj);
					switch ($step)
					{
						case 1:
							if($postObj->Content=="000")
							{
								$resultStr = $this->exitStep($postObj);
							}else
							{
								$resultStr = $this->saveAdvice($postObj);
							}							
							break;
						case 0:
							$resultStr = $this->receiveText($postObj);
							break;
						default:
							break;
					}					
					break;								                
                default:
                    $resultStr = "";
                    break;
            }
            echo $resultStr;	

        }else {
            echo "";
            exit;
        }
    }

	/*数据库操作*/
	public function dbConnect_adv()
    {
		include ("pdo_class.php");
		$db_adv=new mysql('advice');
		return $db_adv;		
    } 

	public function saveAdvice($object)//把反馈意见存入数据库
	{			
	
	    $db_adv=$this->dbConnect_adv();
        $db_adv->insert('advice','`aid`,`name`,`adv`',"'','{$object->FromUserName}','{$object->Content}'"); 
				
        $funcFlag = 0;
        $contentStr = "已收到您的反馈，谢谢支持~";
        $resultStr = $this->transmitText($object, $contentStr, $funcFlag);
        return $resultStr;		
	}

	
	public function dbConnect_ope()
    {
		include ("pdo_class.php");
		$db_ope=new mysql('operation');
		return $db_ope;		
    } 
	
	public function subscribe($object)//添加关注后记录用户
	{
		$db_ope=$this->dbConnect_ope();
		$db_ope->insert('operation','`sid`,`name`,`step`',"'','{$object->FromUserName}','0'"); 
	}
	
	public function saveStep($object)//记录步骤，进入意见反馈功能
	{
		$db_ope=$this->dbConnect_ope();
		$db_ope->update('operation',"`step`='1'","name='{$object->FromUserName}'");//step=1表示进入意见反馈功能 
	}
	
	public function checkStep($object)//检查步骤，是否进入意见反馈功能，即step是否为1
	{
		$db_ope=$this->dbConnect_ope();
		$db_ope->prepare_select('*','operation',"`name`=?");
		$db_ope->setFetchMode_assoc();
		$db_ope->casenatural();
		$db_ope->bindParam(1,'{$object->FromUserName}');
		$db_ope->execute();
		$arr=$db_ope->fetch();	
		$res=$arr['step'];
		return $res;

	}
	
	public function exitStep($object)//000退出意见反馈功能
	{
		$db=$this->dbConnect_ope();
		$db->update('operation',"`step`='0'","name='{$object->FromUserName}'");	
		
		$funcFlag = 0;
        $contentStr = "您将退出该功能!";
        $resultStr = $this->transmitText($object, $contentStr, $funcFlag);
        return $resultStr;		
	}
 
	
    public function receiveText($object)
    {
        $funcFlag = 0;
        $contentStr = "你发送的内容为：".$object->Content;
        $resultStr = $this->transmitText($object, $contentStr, $funcFlag);
        return $resultStr;
    }
	
	
    public function receiveEvent($object)
    {
		$type = "";
        $contentStr = "";
        switch ($object->Event)
        {
            case "subscribe":
                $contentStr = "欢迎关注贴心小助手！";
				$this->subscribe($object);
				break;
            case "unsubscribe":
                break;
            case "CLICK":
                switch ($object->EventKey)
                {
                    case "weather":
						$contentStr=$this->forecast();
                        break;
                    case "underground":
                        $contentStr[] = array("Title" =>"广州市地铁线路图", 
                        "Description" =>"点击查看大图", 
                        "PicUrl" =>"http://378711563-picture.stor.sinaapp.com/underground.jpg", 
                        "Url" =>"http://378711563-picture.stor.sinaapp.com/underground.jpg");
                        break;
					case "timetable":
						$contentStr[] = array("Title" =>"信工四班课表", 
                        "Description" =>"点击查看大图", 
                        "PicUrl" =>"http://378711563-picture.stor.sinaapp.com/timetable.png", 
                        "Url" =>"http://378711563-picture.stor.sinaapp.com/timetable.png");
						break;
					case "homework":
						$contentStr = "暂无作业";
						break;
					case 'nba':
						$contentStr = $this->nba();
						break;
					case 'nba_tom':
						$contentStr = $this->nba_tom();
						break;
					case "music":
						$contentStr = array("Title" => "last of us",
						"Description" => "游戏美国末日的插曲",
						"MusicUrl" => "http://378711563-music.stor.sinaapp.com/music.mp3",
						"HQMusicUrl" => "http://378711563-music.stor.sinaapp.com/music.mp3");						
						$type="music";				
						break;
					case "drama":
						$contentStr[] = array("Title" =>"电视剧红色 良心国产", 
                        "Description" =>"豆瓣高分9.3，福尔摩斯般的探案，花样年华般的爱情,(点击跳转B站链接)", 
                        "PicUrl" =>"http://378711563-picture.stor.sinaapp.com/drama.jpg", 
                        "Url" =>"http://www.bilibili.com/video/av1594747/");
                        break;
					case "advice":
						$contentStr = "您将进行意见反馈，请输入您的意见！若不进行反馈，输入000退出。";
						$type="advice";
						break;
					case "contact":
						$contentStr = "QQ:378711563 e-mail:378711563@qq.com 任何问题，欢迎叨唠！";
						break;
					default:
                        $contentStr[] = array("Title" =>"默认菜单回复", 
                        "Description" =>"贴心小助手", 
                        "PicUrl" =>"http://discuz.comli.com/weixin/weather/icon/cartoon.jpg", 
                        "Url" =>"weixin://addfriend/pondbaystudio");
                        break;
                }
                break;
            default:
                break;      

        }
        if (is_array($contentStr)){
			if($type=="music")
			{
				$resultStr = $this->transmitMusic($object,$contentStr);
			}else
			{
				$resultStr = $this->transmitNews($object, $contentStr);
			}          
        }else{
			if($type=="advice")
			{
				$this->saveStep($object);
				$resultStr = $this->transmitText($object, $contentStr);				
			}else
			{
				$resultStr = $this->transmitText($object, $contentStr);
			}
            
        }
        return $resultStr;
    }

    public function transmitText($object, $content, $funcFlag = 0)
    {
        $textTpl = "<xml>
					<ToUserName><![CDATA[%s]]></ToUserName>
					<FromUserName><![CDATA[%s]]></FromUserName>
					<CreateTime>%s</CreateTime>
					<MsgType><![CDATA[text]]></MsgType>
					<Content><![CDATA[%s]]></Content>
					<FuncFlag>%d</FuncFlag>
					</xml>";
        $resultStr = sprintf($textTpl, $object->FromUserName, $object->ToUserName, time(), $content, $funcFlag);
        return $resultStr;
    }

    public function transmitNews($object, $arr_item, $funcFlag = 0)
    {
        if(!is_array($arr_item))
            return;

        $itemTpl = "<item>
					<Title><![CDATA[%s]]></Title>
					<Description><![CDATA[%s]]></Description>
					<PicUrl><![CDATA[%s]]></PicUrl>
					<Url><![CDATA[%s]]></Url>
					</item>";
        $item_str = "";
        foreach ($arr_item as $item)
            $item_str .= sprintf($itemTpl, $item['Title'], $item['Description'], $item['PicUrl'], $item['Url']);

        $newsTpl = "<xml>
					<ToUserName><![CDATA[%s]]></ToUserName>
					<FromUserName><![CDATA[%s]]></FromUserName>
					<CreateTime>%s</CreateTime>
					<MsgType><![CDATA[news]]></MsgType>
					<Content><![CDATA[]]></Content>
					<ArticleCount>%s</ArticleCount>
					<Articles>
					$item_str</Articles>
					<FuncFlag>%s</FuncFlag>
					</xml>";

        $resultStr = sprintf($newsTpl, $object->FromUserName, $object->ToUserName, time(), count($arr_item), $funcFlag);
        return $resultStr;
    }
	
	public function transmitMusic($object, $item, $funcFlag = 0)
    {
        if(!is_array($item))
            return;

        $itemTpl = "<Title><![CDATA[%s]]></Title>
					<Description><![CDATA[%s]]></Description>
					<MusicUrl><![CDATA[%s]]></MusicUrl>
					<HQMusicUrl><![CDATA[%s]]></HQMusicUrl>";
        $item_str = "";
        $item_str .= sprintf($itemTpl, $item['Title'], $item['Description'], $item['MusicUrl'], $item['HQMusicUrl']);

        $newsTpl = "<xml>
					<ToUserName><![CDATA[%s]]></ToUserName>
					<FromUserName><![CDATA[%s]]></FromUserName>
					<CreateTime>%s</CreateTime>
					<MsgType><![CDATA[music]]></MsgType>
					<Music>
					$item_str</Music>
					<FuncFlag>%s</FuncFlag>
					</xml>";

        $resultStr = sprintf($newsTpl, $object->FromUserName, $object->ToUserName, time(), $funcFlag);
        return $resultStr;
    }

	public function forecast()
	{
		function compress_html($string) {  
			$string = str_replace("\r\n", '', $string);   
			$string = str_replace("\n", '', $string);   
			$string = str_replace("\t", '', $string);  
			$pattern = array (  
							"/> *([^ ]*) *</",  
							"/[\s]+/",  
							"/<!--[^!]*-->/",  
							"/\" /",  
							"/ \"/",  
							"'/\*[^*]*\*/'" 
							);  
			$replace = array (  
							">\\1<",  
							" ",  
							"",  
							"\"",  
							"\"",  
							"" 
							);  

		return preg_replace($pattern, $replace, $string);  
		}

		$url="http://www.weather.com.cn/weather/101280101.shtml";
		$page_content=file_get_contents($url); 
		$page_content=compress_html($page_content);
		preg_match("/\"t clearfix\"(.*?)后天/",$page_content,$result);
		preg_match("/\"hidden_title\"(.*?>)/",$page_content,$today);
		preg_match("/明天(.*?)slid/",$result[1],$tomo);
		preg_match("/后天(.*?)slid/",$page_content,$tdat);

		/*今天*/
		$a=explode(" ",$today[1]);

		//气候
		$weather=$a[2];
		//最高温度
		$b=explode("/",$a[3]);
		$c=explode("°C",$b[1]);	
		$max_tem=$c[0];
		//最低温度
		$min_tem=$b[0];
		

		/*明天*/

		$a1=explode("<",$tomo[1]);
		//气候
		$b1=explode(">",$a1[6]);
		$weather1=$b1[1];
		//最高温度
		$d1=explode(">",$a1[9]);
		$max_tem1=$d1[1];
		//最低温度
		$e1=explode(">",$a1[11]);
		$min_tem1=$e1[1];
		//风速
		$f1=explode(">",$a1[21]);
		$wind1=$f1[1];


		/*后天*/
		$a2=explode("<",$tdat[1]);
		//气候
		$b2=explode(">",$a2[6]);
		$weather2=$b2[1];
		//最高温度
		$d2=explode(">",$a2[9]);
		$max_tem2=$d2[1];
		//最低温度
		$e2=explode(">",$a2[11]);
		$min_tem2=$e2[1];
		//风速
		$f2=explode(">",$a2[21]);
		$wind2=$f2[1];
		
		if($weather=="晴"){$picurl="http://378711563-picture.stor.sinaapp.com/qing.jpg";}else
		if($weather=="多云"){$picurl="http://378711563-picture.stor.sinaapp.com/duoyun.jpg";}else
		if($weather=="阴"){$picurl="http://378711563-picture.stor.sinaapp.com/yin.jpg";}else
		if($weather=="暴风"||$weather=="台风"){$picurl="http://378711563-picture.stor.sinaapp.com/baofentaifen.jpg";}else
		if($weather=="暴雨"){$picurl="http://378711563-picture.stor.sinaapp.com/baoyu.jpg";}else
		if($weather=="冰雹"){$picurl="http://378711563-picture.stor.sinaapp.com/bingbao.jpg";}else
		if($weather=="雷阵雨"){$picurl="http://378711563-picture.stor.sinaapp.com/leizhenyu.jpg";}else
		if($weather=="雾"||$weather=="霾"){$picurl="http://378711563-picture.stor.sinaapp.com/wumai.jpg";}else
		if($weather=="小雪"||$weather=="中雪"||$weather=="大雪"){$picurl="http://378711563-picture.stor.sinaapp.com/xiaoxuedaxuezhongxue.jpg";}else
		if($weather=="雨夹雪"){$picurl="http://378711563-picture.stor.sinaapp.com/yujiaxue.jpg";}else
		if($weather=="小雨"||$weather=="中雨"||$weather=="大雨"||$weather=="阵雨"){$picurl="http://378711563-picture.stor.sinaapp.com/xiaoyuzhongyudayuzhenyu.jpg";}
		
		if($weather1=="晴"){$picurl1="http://378711563-picture.stor.sinaapp.com/qing.jpg";}else
		if($weather1=="多云"){$picurl1="http://378711563-picture.stor.sinaapp.com/duoyun.jpg";}else
		if($weather1=="阴"){$picurl1="http://378711563-picture.stor.sinaapp.com/yin.jpg";}else
		if($weather1=="暴风"||$weather=="台风"){$picurl1="http://378711563-picture.stor.sinaapp.com/baofentaifen.jpg";}else
		if($weather1=="暴雨"){$picurl1="http://378711563-picture.stor.sinaapp.com/baoyu.jpg";}else
		if($weather1=="冰雹"){$picurl1="http://378711563-picture.stor.sinaapp.com/bingbao.jpg";}else
		if($weather1=="雷阵雨"){$picurl1="http://378711563-picture.stor.sinaapp.com/leizhenyu.jpg";}else
		if($weather1=="雾"||$weather1=="霾"){$picurl1="http://378711563-picture.stor.sinaapp.com/wumai.jpg";}else
		if($weather1=="小雪"||$weather1=="中雪"||$weather1=="大雪"){$picurl1="http://378711563-picture.stor.sinaapp.com/xiaoxuedaxuezhongxue.jpg";}else
		if($weather1=="雨夹雪"){$picurl="http://378711563-picture.stor.sinaapp.com/yujiaxue.jpg";}else
		if($weather1=="小雨"||$weather1=="中雨"||$weather1=="大雨"||$weather1=="阵雨"){$picurl1="http://378711563-picture.stor.sinaapp.com/xiaoyuzhongyudayuzhenyu.jpg";}
		
		if($weather2=="晴"){$picurl2="http://378711563-picture.stor.sinaapp.com/qing.jpg";}else
		if($weather2=="多云"){$picurl2="http://378711563-picture.stor.sinaapp.com/duoyun.jpg";}else
		if($weather2=="阴"){$picurl2="http://378711563-picture.stor.sinaapp.com/yin.jpg";}else
		if($weather2=="暴风"||$weather2=="台风"){$picurl2="http://378711563-picture.stor.sinaapp.com/baofentaifen.jpg";}else
		if($weather2=="暴雨"){$picurl2="http://378711563-picture.stor.sinaapp.com/baoyu.jpg";}else
		if($weather2=="冰雹"){$picurl2="http://378711563-picture.stor.sinaapp.com/bingbao.jpg";}else
		if($weather2=="雷阵雨"){$picurl2="http://378711563-picture.stor.sinaapp.com/leizhenyu.jpg";}else
		if($weather2=="雾"||$weather2=="霾"){$picurl2="http://378711563-picture.stor.sinaapp.com/wumai.jpg";}else
		if($weather2=="小雪"||$weather2=="中雪"||$weather2=="大雪"){$picurl2="http://378711563-picture.stor.sinaapp.com/xiaoxuedaxuezhongxue.jpg";}else
		if($weather2=="雨夹雪"){$picurl2="http://378711563-picture.stor.sinaapp.com/yujiaxue.jpg";}else
		if($weather2=="小雨"||$weather2=="中雨"||$weather2=="大雨"||$weather2=="阵雨"){$picurl2="http://378711563-picture.stor.sinaapp.com/xiaoyuzhongyudayuzhenyu.jpg";}
		
		
		$con[]=array("Title" =>"广州天气预报");
		$con[]=array("Title" =>"今天 天气:".$weather." 温度:".$max_tem."-".$min_tem."℃",
		"PicUrl" =>$picurl);
		$con[]=array("Title" =>"明天 天气:".$weather1." 温度:".$max_tem1."-".$min_tem1." 风速:".$wind1,
		"PicUrl" =>$picurl1);
		$con[]=array("Title" =>"后天 天气:".$weather2." 温度:".$max_tem2."-".$min_tem2." 风速:".$wind2,
		"PicUrl" =>$picurl2);             

		return $con;

	}
		
	public function nba()
	{
		function compress_html($string) {  
			$string = str_replace("\r\n", '', $string);   
			$string = str_replace("\n", '', $string);   
			$string = str_replace("\t", '', $string);  
			$pattern = array (  
							"/> *([^ ]*) *</",  
							"/[\s]+/",  
							"/<!--[^!]*-->/",  
							"/\" /",  
							"/ \"/",  
							"'/\*[^*]*\*/'" 
							);  
			$replace = array (  
							">\\1<",  
							" ",  
							"",  
							"\"",  
							"\"",  
							"" 
							);  

		return preg_replace($pattern, $replace, $string);  
		}
		
		$d=intval(date('W',strtotime(date("Y-m-d"))));//计算今日是本年的第几周
		$url="http://nba.sports.163.com/schedule/2016-{$d}.html";//注意：url里的2016-{$d}随周次而变化
		$page_content=file_get_contents($url); 
		$page_content=compress_html($page_content);
		preg_match("/\"in-con2 clearfix\"(.*?)\"blank20\"/",$page_content,$result);	
		$day=explode("blank6",$result[1]);		
		
		for($i=1;$i<=7;$i++)
		{
			//日期
			$k=2*$i-1;
			$date=explode(">",$day[$k]);			
			$date=explode("<",$date[3]);
			
			$date=$date[0];	
			
			$one=explode("nolbo",$day[2*$i]);
			
			$max=count($one);
			
			$now=date("Y年m月d日");
			$week=date("w");		
			if($week==0){$week="日";}else
			if($week==1){$week="一";}else
			if($week==2){$week="二";}else
			if($week==3){$week="三";}else
			if($week==4){$week="四";}else
			if($week==5){$week="五";}else
			if($week==6){$week="六";}
			$now=$now." 星期".$week;

			if($max<=10)
			{
				for($j=1;$j<=$max-1;$j++)
				{													
					$con=explode("<",$one[$j]);
					
					//开球时间		
					$time=explode(">",$con[0]);
					$time=$time[1];

					//客场球队
					$team1=explode(">",$con[4]);	
					$team1=$team1[1];

					//比分(对于未完成的比赛，比分暂用VS表示)
					$score=explode(">",$con[7]);	
					$score=$score[1];

					//主场球队
					$team2=explode(">",$con[12]);	
					$team2=$team2[1];

					if($now==$date)
					{
						$res[0]=array("Title" => $now."赛程");
						$res[$j]=array("Title" => $time."  客场: ".$team1.$score."主场: ".$team2);
					}							
				}
			}else
			{
				for($j=1;$j<=9;$j++)
				{													
					$con=explode("<",$one[$j]);
					
					//开球时间		
					$time=explode(">",$con[0]);
					$time=$time[1];

					//客场球队
					$team1=explode(">",$con[4]);	
					$team1=$team1[1];

					//比分(对于未完成的比赛，比分暂用VS表示)
					$score=explode(">",$con[7]);	
					$score=$score[1];

					//主场球队
					$team2=explode(">",$con[12]);	
					$team2=$team2[1];

					if($now==$date)
					{
						$res[0]=array("Title" => $now."赛程(当天赛程超过十场，省略部分赛程)");
						$res[$j]=array("Title" => $time."  客场: ".$team1.$score."主场: ".$team2);
					}							
				}
			}
		}
		
		return $res;		
	}
	
	public function nba_tom()
	{
		function compress_html($string) {  
			$string = str_replace("\r\n", '', $string);   
			$string = str_replace("\n", '', $string);   
			$string = str_replace("\t", '', $string);  
			$pattern = array (  
							"/> *([^ ]*) *</",  
							"/[\s]+/",  
							"/<!--[^!]*-->/",  
							"/\" /",  
							"/ \"/",  
							"'/\*[^*]*\*/'" 
							);  
			$replace = array (  
							">\\1<",  
							" ",  
							"",  
							"\"",  
							"\"",  
							"" 
							);  

		return preg_replace($pattern, $replace, $string);  
		}
		$d=intval(date('W',strtotime(date("Y-m-d",strtotime("+1 day")))));//计算明日是本年的第几周
		$url="http://nba.sports.163.com/schedule/2016-{$d}.html";//注意：url里的2016-8随周次而变化，记得随时刷新
		$page_content=file_get_contents($url); 
		$page_content=compress_html($page_content);
		preg_match("/\"in-con2 clearfix\"(.*?)\"blank20\"/",$page_content,$result);	
		$day=explode("blank6",$result[1]);		
		
		for($i=1;$i<=7;$i++)
		{
			//日期
			$k=2*$i-1;
			$date=explode(">",$day[$k]);			
			$date=explode("<",$date[3]);
			
			$date=$date[0];	
			
			$one=explode("nolbo",$day[2*$i]);
			
			$max=count($one);
			
			$tom=date("Y年m月d日",strtotime("+1 day"));
			
			$week=date("w");		
			if($week==0){$week="一";}else
			if($week==1){$week="二";}else
			if($week==2){$week="三";}else
			if($week==3){$week="四";}else
			if($week==4){$week="五";}else
			if($week==5){$week="六";}else
			if($week==6){$week="日";}
			$tom=$tom." 星期".$week;
			
			if($max<=10)
			{
				for($j=1;$j<=$max-1;$j++)
				{													
					$con=explode("<",$one[$j]);
					
					//开球时间		
					$time=explode(">",$con[0]);
					$time=$time[1];

					//客场球队
					$team1=explode(">",$con[4]);	
					$team1=$team1[1];

					//比分(对于未完成的比赛，比分暂用VS表示)
					$score=explode(">",$con[7]);	
					$score=$score[1];

					//主场球队
					$team2=explode(">",$con[12]);	
					$team2=$team2[1];

					if($tom==$date)
					{
						$res[0]=array("Title" => $tom."赛程");
						$res[$j]=array("Title" => $time." 客场 ".$team1.$score." 主场 ".$team2);
					}							
				}
			}else
			{
				for($j=1;$j<=9;$j++)
				{													
					$con=explode("<",$one[$j]);
					
					//开球时间		
					$time=explode(">",$con[0]);
					$time=$time[1];

					//客场球队
					$team1=explode(">",$con[4]);	
					$team1=$team1[1];

					//比分(对于未完成的比赛，比分暂用VS表示)
					$score=explode(">",$con[7]);	
					$score=$score[1];

					//主场球队
					$team2=explode(">",$con[12]);	
					$team2=$team2[1];

					if($tom==$date)
					{
						$res[0]=array("Title" => $tom."赛程(当天赛程超过十场，省略部分赛程)");
						$res[$j]=array("Title" => $time." 客场 ".$team1.$score." 主场 ".$team2);
					}							
				}
			}
		}

		return $res;
	}
}
?>